/**
 * Cria um tipo enumerado (enum)
 * 
 * @author Julio Arakaki 
 * @version 20220815
 */
public enum TipoPrimitivo {
    PONTO, RETA, CIRCULO, NENHUM, TRIANGULO, RETANGULO; //adicionei o tipo primitivo triangulo e retangulo
}
